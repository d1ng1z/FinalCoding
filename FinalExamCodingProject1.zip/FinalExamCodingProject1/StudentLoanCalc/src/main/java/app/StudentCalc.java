package app;

import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.io.IOException;

import app.controller.LoanCalcViewController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
public class StudentCalc extends Application {

	private Stage primaryStage;
	
	private BorderPane LoanScreen = null;
	
	private LoanCalcViewController LCVC = null;
	//creates a new Tableview and Observable ArrayLists to be bound to each column;
	private TableView<Double> table = new TableView();
	private  ObservableList<Double> paymentNList = FXCollections.observableArrayList();
	private  ObservableList<Double> InterestList = FXCollections.observableArrayList();
	private  ObservableList<Double> PrincipalList = FXCollections.observableArrayList();
	private  ObservableList<Double> BalanceList = FXCollections.observableArrayList();
	
	
	
	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		this.primaryStage = primaryStage;
		ShowScreen();
		//creates columns for the table with details on monthly payments and balance
		   table.setEditable(false);
		   
	        TableColumn paymentNCol = new TableColumn("Payment #");
	        TableColumn InterestCol = new TableColumn("Interest Payment");
	        TableColumn PrincipalCol = new TableColumn("PrincipalPayment");
	        TableColumn BalanceCol = new TableColumn("Balance");
	        
	        table.getColumns().addAll(paymentNCol, InterestCol, PrincipalCol, BalanceCol);
		
	}
	
	public void ShowScreen() {
		// Parent root;
		try {

			FXMLLoader loader = new FXMLLoader();
			loader = new FXMLLoader(getClass()
					.getResource("/app/view/LoanCalcView.fxml"));
			LoanScreen = (BorderPane) loader.load();
			Scene scene = new Scene(LoanScreen);
			primaryStage.setScene(scene);
			LCVC = loader.getController();
			LCVC.setMainApp(this);
			primaryStage.show();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}

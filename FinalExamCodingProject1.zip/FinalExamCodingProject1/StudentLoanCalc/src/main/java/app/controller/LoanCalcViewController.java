package app.controller;





import javafx.scene.control.Button;

import app.StudentCalc;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.scene.control.DatePicker;

public class LoanCalcViewController implements Initializable   {
	//variables for storing input from textfields
	private double dLoanAmount;
	private double dAnnualRate;
	private double dTerm;
	//variables used in calculations
	private double dMonthlyRate;
	
	private double balance;
	
	private double dMonthlyInterestPayment;
	
	private double dMonthlyPrincipalPayment;
	
	private int Months;
	
	
	
	
	
	
	private double dMonthlyPayment;
	
	private double dTotalPayment;
	
	
	

	
	

	
	
	

	

	private StudentCalc SC = null;
	
	@FXML
	private TextField LoanAmount;
	
	@FXML
	private TextField AnnualInterestRate;
	
	@FXML
	private TextField LoanTerm;
	
	
	
	
	@FXML
	private TextField PeriodRateTextField;
	
	@FXML
	private TextField TotalPaymentsTextField;
	
	@FXML
	private TextField TotalInterestTextField;
	


	

	
	@FXML
	private Label LoanAmountLabel;
	
	@FXML
	private Label AnnualInterestLabel;
	
	@FXML
	private Label LoanTermLabel;
	
	@FXML
	private Label FirstPaymentDateLabel;
	
	@FXML
	private Label PeriodRateLabel;
	
	@FXML
	private Label TotalPaymentsLabel;
	
	
	@FXML
	private Label TotalInterestLabel;
	
	@FXML
	private Label PaymentFrequencyLabel;
	
	
	
	
	
	
	@FXML
	private DatePicker PaymentStartDate;
	
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

	public void setMainApp(StudentCalc sc) {
		this.SC = sc;
	}
	
	/**
	 * btnCalcLoan - Fire this event when the button clicks
	 * 
	 * @version 1.0
	 * @param event
	 */
	@FXML
	private void btnCalcLoan(ActionEvent event) {
		private double dTotalInterest=0;
		
		
		//getting input from textfields in left column
		dLoanAmount = LoanAmount.getText();
		dAnnualRate = AnnualInterestRate.getText();
		dTerm       = LoanTerm.getText();
		//initializing balance to the Loan amount
		balance = dLoanAmount; 
		dMonthlyRate = dAnnualRate/1200;
		//calculating #of months and monthly payment
		Months = dTerm*12;
		MonthlyPayment = dLoanAmount/ balance;
		
		//for loop that calculates the monthly interest and principal payments for current month, updates the current balance , and updates the total interest by adding the current monthly interest. 
		for(double i=1; i<=Months; i+=1);{
			
			paymentNList.add(i)
			//Monthly interest and principal payments
			dMonthlyInterestPayment = dMonthlyRate*balance;
			dMonthlyPrincipalPayment = dMonthlyPayment - dMonthlyInterestPayment;
			
			InterestList.add(dMonthlyInterestPayment);
			PrincipalList.add(dMonthlyPrincipalPayment);
			
			//updating the balance;
			balance=balance-dMonthlyInterestPayment;
			BalanceList.add(balance);
		
			//updating the sum of interest payments;
			dTotalInterest+=dMonthlyInterestPayment;
			
			
		}
		
		
	
		dTotalPayment= dLoanAmount+dTotalInterest;
		
		
		//setting the textfields in the right column to the values stored in instance variables
		
		 PeriodRateTextField.setText(dMonthlyInterestPayment);
		 TotalPaymentsTextField.setText(dTotalPayment);
		 TotalInterestTextField.setText(dTotalInterest);
		 
		 //binding the data in the ObservableList to the Tableview
		 
		 
		

	
	}
	
}
